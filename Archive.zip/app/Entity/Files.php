<?php namespace App\Entity;

use Illuminate\Database\Eloquent\Model;

class Files extends Model {

	protected $table = "files";

}
