<div class="page-title-container">
    <div class="container">
        <div class="page-title pull-left">
            <h2 class="entry-title">{{ $PageTitle }}</h2>
        </div>
        <ul class= "pull-right" style="margin: 4px;">
           <li class="pull-left"><a href="{{ $add }}" class="icon-box style8" alt="Add User"><i class="soap-icon-doc-plus green-bg"></i></a></li>
           <li class="pull-left"><a href="{{ $edit }}" class="icon-box style8" alt="Edit User"><i class="soap-icon-stories yello-bg"></i></a></li>
           <li class="pull-left"><a href="{{ $edit }}" class="icon-box style8" alt="Delete User"><i class="soap-icon-liability red-bg"></i></a></li>
        </ul>

    </div>
</div>