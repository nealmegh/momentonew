<ul class="tabs">
    <li class="active"><a data-toggle="tab" href="#dashboard"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
    <li class=""><a data-toggle="tab" href="#profile"><i class="soap-icon-user circle"></i>Profile</a></li>
    <li class=""><a data-toggle="tab" href="#hotel"><i class="soap-icon-settings circle"></i>Hotel</a></li>
    <li class=""><a data-toggle="tab" href="#booking"><i class="soap-icon-businessbag circle"></i>Booking</a></li>
    <li class=""><a href="{{ url('agents/booking') }}"><i class="soap-icon-wishlist circle"></i>New Booking</a></li>
    {{--<li class=""><a data-toggle="tab" href="#customer-order"><i class="soap-icon-conference circle"></i>Customer/Order</a></li>--}}
    <li class=""><a data-toggle="tab" href="#report"><i class="soap-icon-settings circle"></i>Report</a></li>
    <li class=""><a data-toggle="tab" href="#markup"><i class="soap-icon-settings circle"></i>Markup</a></li>
</ul>