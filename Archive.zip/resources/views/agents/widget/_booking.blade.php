    <h2>Trips You have Booked!</h2>
    <div class="filter-section gray-area clearfix">
        <form>
            <label class="radio radio-inline checked">
                <input type="radio" name="filter" checked="checked">
                All Types
            </label>
            <label class="radio radio-inline">
                <input type="radio" name="filter">
                Hotels
            </label>
            <label class="radio radio-inline">
                <input type="radio" name="filter">
                Flights
            </label>
            <label class="radio radio-inline">
                <input type="radio" name="filter">
                Cars
            </label>
            <label class="radio radio-inline">
                <input type="radio" name="filter">
                Cruises
            </label>
            <div class="pull-right col-md-6 action">
                <h5 class="pull-left no-margin col-md-4">Sort results by:</h5>
                <button class="btn-small white gray-color">UPCOMING</button>
                <button class="btn-small white gray-color">CANCELLED</button>
            </div>
        </form>
    </div>
    <div class="booking-history">
        <div class="booking-info clearfix">
            <div class="date">
                <label class="month">NOV</label>
                <label class="date">23</label>
                <label class="day">SAT</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-plane-right takeoff-effect yellow-color circle"></i>Indianapolis to Paris<small>you are flying</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>saturday, nov 23, 2013</dd>
            </dl>
            <button class="btn-mini status">UPCOMMING</button>
        </div>
        <div class="booking-info clearfix">
            <div class="date">
                <label class="month">NOV</label>
                <label class="date">30</label>
                <label class="day">SAT</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-plane-right takeoff-effect yellow-color circle"></i>England to Rome<small>you are flying</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>saturday, nov 30, 2013</dd>
            </dl>
            <button class="btn-mini status">UPCOMMING</button>
        </div>
        <div class="booking-info clearfix">
            <div class="date">
                <label class="month">DEC</label>
                <label class="date">11</label>
                <label class="day">MON</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-hotel blue-color circle"></i>Hilton Hotel &amp; Resorts<small>2 adults staying</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>monday, dec 11, 2013</dd>
            </dl>
            <button class="btn-mini status">UPCOMMING</button>
        </div>
        <div class="booking-info clearfix">
            <div class="date">
                <label class="month">DEC</label>
                <label class="date">18</label>
                <label class="day">THU</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-car red-color circle"></i>Economy Car<small>you are driving</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>thursday, dec 18, 2013</dd>
            </dl>
            <button class="btn-mini status">UPCOMMING</button>
        </div>
        <div class="booking-info clearfix">
            <div class="date">
                <label class="month">DEC</label>
                <label class="date">22</label>
                <label class="day">SUN</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-cruise green-color circle"></i>Baja Mexico<small>3 adults going on cruise</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>sunday, dec 22, 2013</dd>
            </dl>
            <button class="btn-mini status">UPCOMMING</button>
        </div>
        <div class="booking-info clearfix cancelled">
            <div class="date">
                <label class="month">NOV</label>
                <label class="date">30</label>
                <label class="day">SAT</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-plane-right takeoff-effect circle"></i>England to Rome<small>you are flying</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>saturday, nov 30, 2013</dd>
            </dl>
            <button class="btn-mini status">CANCELLED</button>
        </div>
        <div class="booking-info clearfix cancelled">
            <div class="date">
                <label class="month">DEC</label>
                <label class="date">18</label>
                <label class="day">THU</label>
            </div>
            <h4 class="box-title"><i class="icon soap-icon-car circle"></i>Economy Car<small>you are driving</small></h4>
            <dl class="info">
                <dt>TRIP ID</dt>
                <dd>5754-8dk8-8ee</dd>
                <dt>booked on</dt>
                <dd>thursday, dec 18, 2013</dd>
            </dl>
            <button class="btn-mini status">CANCELLED</button>
        </div>
    </div>
