<ul class="tabs">
    <li class=""><a href="{{ url('admin/reviews?filter=all') }}"><i class="soap-icon-block circle"></i>All Reviews</a></li>
    <li class=""><a href="{{ url('admin/reviews?filter=hotel') }}"><i class="soap-icon-hotel circle"></i>Hotel</a></li>
    <li class=""><a href="{{ url('admin/reviews?filter=tour') }}"><i class="soap-icon-beach circle"></i>Tour</a></li>
    <li class=""><a href="{{ url('admin/reviews/types') }}"><i class="soap-icon-businessbag circle"></i>Reviews Types</a></li>
</ul>