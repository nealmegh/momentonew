<ul class="tabs">
    <li class="active"><a href="{{ url('admin/agents') }}"><i class="soap-icon-wishlist circle"></i>Manage Agents</a></li>
    {{--<li class=""><a href="{{ url('admin/articles/create') }}"><i class="soap-icon-businessbag circle"></i>Create New Articles</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/articles/role') }}"><i class="soap-icon-user circle"></i>Link Menu</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/articles/draft') }}"><i class="soap-icon-user circle"></i>Published As Draft</a></li>--}}
</ul>