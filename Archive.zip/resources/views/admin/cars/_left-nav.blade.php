<ul class="tabs">
    <li class=""><a href="{{ url('admin/cars') }}"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
    <li class=""><a href="{{ url('admin/cars/manage') }}"><i class="soap-icon-anchor circle"></i>All Car</a></li>
    {{--<li class=""><a href="{{ url('admin/car/grade') }}"><i class="soap-icon-user circle"></i>Car Grade</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/car/room-type') }}"><i class="soap-icon-businessbag circle"></i>All Room Type</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/car/vacancy') }}"><i class="soap-icon-businessbag circle"></i>Room Vacancies</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/car/facility') }}"><i class="soap-icon-businessbag circle"></i>Car Facility</a></li>--}}
    <li class=""><a href="{{ url('admin/cars/review') }}"><i class="soap-icon-businessbag circle"></i>Review</a></li>
</ul>