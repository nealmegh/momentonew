<ul class="tabs">
    <li class="active"><a href="#dashboard"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
    <li class=""><a href="#hotel"><i class="soap-icon-hotel-1 circle"></i>Hotel Booking</a></li>
    <li class=""><a href="#tour"><i class="soap-icon-baggage circle"></i>Tour Booking</a></li>
    <li class=""><a href="#car"><i class="soap-icon-car circle"></i>Car Booking</a></li>
</ul>