<ul class="tabs">
    <li class=""><a href="{{ url('admin/tours') }}"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
    <li class=""><a href="{{ url('admin/tours/manage') }}"><i class="soap-icon-anchor circle"></i>All Tour</a></li>
    <li class=""><a href="{{ url('admin/tours/category') }}"><i class="soap-icon-user circle"></i>Car Category</a></li>
    {{--<li class=""><a href="{{ url('admin/tour/grade') }}"><i class="soap-icon-user circle"></i>Hotel Grade</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/hotels/room-type') }}"><i class="soap-icon-businessbag circle"></i>All Room Type</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/hotels/vacancy') }}"><i class="soap-icon-businessbag circle"></i>Room Vacancies</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/tour/facility') }}"><i class="soap-icon-businessbag circle"></i>Hotel Facility</a></li>--}}
    <li class=""><a href="{{ url('admin/tours/review') }}"><i class="soap-icon-businessbag circle"></i>Review</a></li>
</ul>