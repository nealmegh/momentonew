<ul class="tabs">
    <li class=""><a href="{{ url('admin/flights') }}"><i class="soap-icon-anchor circle"></i>Dashboard</a></li>
    <li class=""><a href="{{ url('admin/flights/manage') }}"><i class="soap-icon-anchor circle"></i>All Flight</a></li>
    <li class=""><a href="{{ url('admin/flights/review') }}"><i class="soap-icon-businessbag circle"></i>Review</a></li>
</ul>