<ul class="tabs">
    <li class=""><a href="{{ url('admin/users/profile') }}"><i class="soap-icon-user circle"></i>Your Profile</a></li>
    <li class=""><a href="{{ url('admin/users?manage=admins') }}"><i class="soap-icon-doorman circle"></i>Manage Admins</a></li>
    <li class=""><a href="{{ url('admin/users?manage=agents') }}"><i class="soap-icon-man-3 circle"></i>Manage Agents</a></li>
    <li class=""><a href="{{ url('admin/users?manage=customers') }}"><i class="soap-icon-adventure circle"></i>Manage Customers</a></li>
    <li class=""><a href="{{ url('admin/users?manage=user-roles') }}"><i class="soap-icon-myspace circle"></i>User Roles</a></li>
</ul>