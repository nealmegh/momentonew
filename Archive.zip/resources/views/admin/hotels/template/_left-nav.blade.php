<ul class="tabs">
    <li class=""><a href="{{ url('admin/hotels/manage') }}"><i class="soap-icon-hotel circle"></i>All Hotel</a></li>
    <li class=""><a href="{{ url('admin/hotels/category') }}"><i class="soap-icon-block circle"></i>Hotel Category</a></li>
    <li class=""><a href="{{ url('admin/hotels/grade') }}"><i class="soap-icon-star circle"></i>Hotel Grade</a></li>
    {{--<li class=""><a href="{{ url('admin/hotels/room-type') }}"><i class="soap-icon-businessbag circle"></i>All Room Type</a></li>--}}
    {{--<li class=""><a href="{{ url('admin/hotels/vacancy') }}"><i class="soap-icon-businessbag circle"></i>Room Vacancies</a></li>--}}
    <li class=""><a href="{{ url('admin/hotels/facility') }}"><i class="soap-icon-baggage-status circle"></i>Hotel Facility</a></li>
{{--    <li class=""><a href="{{ url('admin/hotels/review') }}"><i class="soap-icon-businessbag circle"></i>Review</a></li>--}}
</ul>