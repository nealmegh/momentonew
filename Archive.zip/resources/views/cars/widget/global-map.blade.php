<div class="global-map-area promo-box no-margin parallax" data-stellar-background-ratio="0.5">
    <div class="container">
        <div class="content-section description pull-right col-sm-9">
            <div class="table-wrapper hidden-table-sm">
                <div class="table-cell">
                    <h2 class="m-title animated" data-animation-type="fadeInDown">
                        Tell us where you would like to go.<br /><em>12,000+ Hotel and Resorts Available!</em>
                    </h2>
                </div>
                {{--<div class="table-cell action-section col-md-4 no-float">--}}
                    {{--<form action="http://www.soaptheme.net/html/travelo/hotel-list-view.html" method="post">--}}
                        {{--<div class="row">--}}
                            {{--<div class="col-xs-6 col-md-12">--}}
                                {{--<input type="text" class="input-text input-large full-width" value="" placeholder="Enter destination or hotel name" />--}}
                            {{--</div>--}}
                            {{--<div class="col-xs-6 col-md-12">--}}
                                {{--<button class="full-width btn-large animated" data-animation-type="fadeInUp" data-animation-delay="1">search hotels</button>--}}
                            {{--</div>--}}
                        {{--</div>--}}
                    {{--</form>--}}
                {{--</div>--}}
            </div>
        </div>
        <div class="image-container col-sm-4">
            <img src="{{ asset('images/shortcodes/promo-image1.png') }}" alt="" width="342" height="258" class="animated" data-animation-type="fadeInUp" data-animation-duration="2" />
        </div>
    </div>
</div>