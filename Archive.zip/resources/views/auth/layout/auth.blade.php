@extends('master')

@section('content')
    <div class="container">
        <div id="main">
            @yield('auth-content')
        </div>
    </div>
    </div>
@endsection